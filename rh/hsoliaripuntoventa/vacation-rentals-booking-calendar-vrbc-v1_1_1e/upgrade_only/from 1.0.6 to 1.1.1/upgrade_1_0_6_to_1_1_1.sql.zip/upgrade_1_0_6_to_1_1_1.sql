-- phpMyAdmin SQL Dump
-- version 4.4.15.9
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 09, 2018 at 03:35 PM
-- Server version: 5.6.37
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- --------------------------------------------------------

--
-- Table structure for table `calendar_details`
--

LOCK TABLES `calendar_details` WRITE;
ALTER TABLE `calendar_details` ADD COLUMN balancedue decimal(9,2) NOT NULL AFTER note_en;
ALTER TABLE `calendar_details` ADD COLUMN deposit decimal(9,2) NOT NULL AFTER note_en;
ALTER TABLE `calendar_details` ADD COLUMN amount decimal(9,2) NOT NULL AFTER note_en;
UNLOCK TABLES;


-- --------------------------------------------------------

--
-- Table structure for table `calendar_files`
--

DROP TABLE IF EXISTS `calendar_files`;
CREATE TABLE IF NOT EXISTS `calendar_files` (
  `id` int(11) NOT NULL,
  `bookingid` int(11) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `filetitle` varchar(100) DEFAULT NULL,
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------


--
-- Table structure for table `property_types`
--

LOCK TABLES `property_types` WRITE;
ALTER TABLE `property_types` ADD COLUMN hideinpub tinyint(1) NOT NULL AFTER sort;
UNLOCK TABLES;

-- --------------------------------------------------------


--
-- Updating data for table `sys_config`
--

UPDATE `sys_config` SET `sysappname` = 'Vacation Rentals Booking Calendar',`sysappver` = '1.1.1' WHERE `sys_config`.`cid` = 1;


-- --------------------------------------------------------

--
-- Table structure for table `sys_users`
--

LOCK TABLES `sys_users` WRITE;
ALTER TABLE `sys_users` ADD COLUMN pptassignment text AFTER akey;
UNLOCK TABLES;

-- --------------------------------------------------------


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;